const express = require('express');
const router = express.Router();
const pool = require('../db');
const authMiddleware = require('../middleware/auth');
const { upload, uploadToStorage } = require('../storage');
const { getOfficeQueryFilter } = require('../utils/helpers');

// GET /api/qurban/distribution-points (Fetch active distribution points)
router.get('/distribution-points', authMiddleware, async (req, res) => {
  try {
    const officeFilter = getOfficeQueryFilter(req.user, 'office');
    const [points] = await pool.query(
      `SELECT * FROM distribusiqurban WHERE status = 'ON' AND ${officeFilter.sql} ORDER BY wilayahdistribusi ASC`,
      officeFilter.params
    );
    res.json(points);
  } catch (err) {
    console.error('Fetch Distribution Points Error:', err);
    res.status(500).json({ message: 'Internal server error' });
  }
});

// GET /api/qurban/dashboard-stats (Dashboard metrics for Qurban)
router.get('/dashboard-stats', authMiddleware, async (req, res) => {
  const { office, year, product, status, pointId } = req.query;

  try {
    const officeFilter = getOfficeQueryFilter(req.user, 'q.office');
    let sqlConditions = [officeFilter.sql];
    let params = [...officeFilter.params];

    if (office) {
      sqlConditions.push('q.office = ?');
      params.push(office);
    }
    if (year) {
      sqlConditions.push('YEAR(q.tgl) = ?');
      params.push(year);
    }
    if (product) {
      sqlConditions.push('q.produk = ?');
      params.push(product);
    }
    if (status) {
      sqlConditions.push('q.status = ?');
      params.push(status);
    }
    if (pointId) {
      sqlConditions.push('q.distribusi = ?');
      params.push(pointId);
    }

    const whereClause = sqlConditions.join(' AND ');

    // 1. Core aggregates
    const [aggregates] = await pool.query(
      `SELECT 
        COUNT(q.detail_id) as total_animals,
        SUM(CAST(NULLIF(q.qty, '') AS SIGNED)) as total_qty,
        SUM(CAST(NULLIF(q.sub_total, '') AS DECIMAL(20,2))) as total_nominal,
        COUNT(DISTINCT q.donaturid) as total_donators
       FROM dataqurban q
       WHERE ${whereClause}`,
      params
    );

    // 2. Status counts
    const [statusBreakdown] = await pool.query(
      `SELECT q.status, COUNT(q.detail_id) as count
       FROM dataqurban q
       WHERE ${whereClause}
       GROUP BY q.status`,
      params
    );

    // 3. Products breakdown
    const [productBreakdown] = await pool.query(
      `SELECT q.produk, COUNT(q.detail_id) as count, SUM(CAST(NULLIF(q.sub_total, '') AS DECIMAL(20,2))) as amount
       FROM dataqurban q
       WHERE ${whereClause}
       GROUP BY q.produk
       ORDER BY count DESC`,
      params
    );

    // 4. Map Distribution Points (aggregates of animals distributed)
    const [mapItems] = await pool.query(
      `SELECT 
        d.id as point_id,
        d.wilayahdistribusi as name,
        d.prov, d.kab, d.kec, d.kel,
        d.user_pj,
        q.produk,
        SUM(CAST(NULLIF(q.qty, '') AS SIGNED)) as product_qty,
        SUM(CAST(NULLIF(q.sub_total, '') AS DECIMAL(20,2))) as product_amount
       FROM dataqurban q
       JOIN distribusiqurban d ON q.distribusi = d.id
       WHERE ${whereClause}
       GROUP BY d.id, q.produk`,
      params
    );

    // Coordinates mapper for Leaflet
    const provinceCoordinates = {
      // Indonesia Provinces
      'ACEH': { lat: 4.6951, lng: 96.7494 },
      'SUMATERA UTARA': { lat: 2.1121, lng: 99.3982 },
      'SUMATERA BARAT': { lat: -0.7399, lng: 100.8000 },
      'RIAU': { lat: 0.5074, lng: 101.5408 },
      'JAMBI': { lat: -1.6101, lng: 103.6131 },
      'SUMATERA SELATAN': { lat: -3.3194, lng: 104.9145 },
      'BENGKULU': { lat: -3.7928, lng: 102.2608 },
      'LAMPUNG': { lat: -4.5586, lng: 105.4000 },
      'KEPULAUAN BANGKA BELITUNG': { lat: -2.7410, lng: 106.4406 },
      'KEPULAUAN RIAU': { lat: 3.9457, lng: 108.1429 },
      'DKI JAKARTA': { lat: -6.2088, lng: 106.8456 },
      'JAKARTA': { lat: -6.2088, lng: 106.8456 },
      'JAWA BARAT': { lat: -7.0909, lng: 107.6689 },
      'JAWA TENGAH': { lat: -7.1510, lng: 110.1402 },
      'DI YOGYAKARTA': { lat: -7.8753, lng: 110.4262 },
      'YOGYAKARTA': { lat: -7.8753, lng: 110.4262 },
      'JAWA TIMUR': { lat: -7.5360, lng: 112.2331 },
      'BANTEN': { lat: -6.4058, lng: 106.0640 },
      'BALI': { lat: -8.4095, lng: 115.1889 },
      'NUSA TENGGARA BARAT': { lat: -8.6529, lng: 117.3616 },
      'NUSA TENGGARA TIMUR': { lat: -8.6573, lng: 121.0794 },
      'KALIMANTAN BARAT': { lat: -0.2788, lng: 111.4753 },
      'KALIMANTAN TENGAH': { lat: -1.6814, lng: 113.3824 },
      'KALIMANTAN SELATAN': { lat: -3.0926, lng: 115.2838 },
      'KALIMANTAN TIMUR': { lat: 1.6406, lng: 116.4194 },
      'KALIMANTAN UTARA': { lat: 3.0731, lng: 116.0414 },
      'SULAWESI UTARA': { lat: 0.6247, lng: 123.9750 },
      'SULAWESI TENGAH': { lat: -1.4300, lng: 121.4456 },
      'SULAWESI SELATAN': { lat: -3.6687, lng: 119.9740 },
      'SULAWESI TENGGARA': { lat: -4.1449, lng: 122.1746 },
      'GORONTALO': { lat: 0.6999, lng: 122.4467 },
      'SULAWESI BARAT': { lat: -2.8441, lng: 119.2321 },
      'MALUKU': { lat: -3.2385, lng: 130.1453 },
      'MALUKU UTARA': { lat: 1.5700, lng: 127.8000 },
      'PAPUA': { lat: -4.2699, lng: 138.0803 },
      'PAPUA BARAT': { lat: -1.3361, lng: 132.9000 },
      'PAPUA SELATAN': { lat: -7.5000, lng: 139.5000 },
      'PAPUA TENGAH': { lat: -4.0000, lng: 136.0000 },
      'PAPUA PEGUNUNGAN': { lat: -4.5000, lng: 139.0000 },
      'PAPUA BARAT DAYA': { lat: -1.1500, lng: 131.5000 }
    };

    // Group product data by distribution point for UI map pins
    const pointsMap = {};
    mapItems.forEach(item => {
      if (!pointsMap[item.point_id]) {
        const normProv = (item.prov || '').toUpperCase().trim();
        let baseCoords = provinceCoordinates[normProv];

        if (!baseCoords) {
          // Check for overseas keywords in province name
          if (normProv.includes('UGANDA')) baseCoords = { lat: 1.3733, lng: 32.2903 };
          else if (normProv.includes('SUDAN')) baseCoords = { lat: 12.8628, lng: 30.2176 };
          else if (normProv.includes('KENYA')) baseCoords = { lat: -0.0236, lng: 37.9062 };
          else if (normProv.includes('CAMEROON')) baseCoords = { lat: 7.3697, lng: 12.3547 };
          else if (normProv.includes('MALI')) baseCoords = { lat: 17.5707, lng: -3.9962 };
          else if (normProv.includes('PALESTINA') || normProv.includes('GAZA')) baseCoords = { lat: 31.9522, lng: 35.2332 };
          else if (normProv.includes('YORDANIA') || normProv.includes('JORDAN')) baseCoords = { lat: 30.5852, lng: 36.2384 };
          else if (normProv.includes('MYANMAR') || normProv.includes('RAKHINE')) baseCoords = { lat: 21.9162, lng: 95.9560 };
          else if (normProv.includes('SOMALIA')) baseCoords = { lat: 5.1521, lng: 46.1996 };
          else if (normProv.includes('TANZANIA')) baseCoords = { lat: -6.3690, lng: 34.8888 };
          else if (normProv.includes('NIGER')) baseCoords = { lat: 17.6078, lng: 8.0817 };
          else if (normProv.includes('TIMOR LESTE')) baseCoords = { lat: -8.8742, lng: 125.7275 };
          else {
            // Default fallback
            baseCoords = { lat: -6.2088, lng: 106.8456 };
          }
        }

        // Jitter based on point_id
        let hash = 0;
        for (let i = 0; i < item.point_id.length; i++) {
          hash = item.point_id.charCodeAt(i) + ((hash << 5) - hash);
        }
        const jitterLat = ((hash & 0xFF) / 255 - 0.5) * 0.15;
        const jitterLng = (((hash >> 8) & 0xFF) / 255 - 0.5) * 0.15;

        pointsMap[item.point_id] = {
          id: item.point_id,
          name: item.name,
          address: `Kel. ${item.kel || ''}, Kec. ${item.kec || ''}, ${item.kab || ''}, ${item.prov || ''}`,
          user_pj: item.user_pj,
          lat: baseCoords.lat + jitterLat,
          lng: baseCoords.lng + jitterLng,
          qurbans: [],
          totalQty: 0,
          totalAmount: 0
        };
      }
      
      const qty = parseInt(item.product_qty || 0);
      const amount = parseFloat(item.product_amount || 0);
      
      pointsMap[item.point_id].qurbans.push({
        product: item.produk,
        qty: qty,
        amount: amount
      });
      pointsMap[item.point_id].totalQty += qty;
      pointsMap[item.point_id].totalAmount += amount;
    });

    res.json({
      aggregates: aggregates[0] || {},
      statusBreakdown,
      productBreakdown,
      mapData: Object.values(pointsMap)
    });
  } catch (err) {
    console.error('Fetch Qurban Stats Error:', err);
    res.status(500).json({ message: 'Internal server error' });
  }
});

// GET /api/qurban (list with filters)
router.get('/', authMiddleware, async (req, res) => {
  const { donatur, status, office, pointId, page = 1, limit = 10 } = req.query;
  const offset = (page - 1) * limit;

  try {
    const officeFilter = getOfficeQueryFilter(req.user, 'q.office');
    let sqlConditions = [officeFilter.sql];
    let params = [...officeFilter.params];

    if (donatur) {
      sqlConditions.push('q.donatur LIKE ?');
      params.push(`%${donatur}%`);
    }
    if (status) {
      sqlConditions.push('q.status = ?');
      params.push(status);
    }
    if (office) {
      sqlConditions.push('q.office = ?');
      params.push(office);
    }
    if (pointId) {
      sqlConditions.push('q.distribusi = ?');
      params.push(pointId);
    }

    const whereClause = sqlConditions.join(' AND ');

    // Get total count
    const [countResult] = await pool.query(
      `SELECT COUNT(*) as total FROM dataqurban q WHERE ${whereClause}`,
      params
    );
    const total = countResult[0].total;

    // Get list
    const [items] = await pool.query(
      `SELECT q.*, d.wilayahdistribusi as point_name, d.user_pj 
       FROM dataqurban q 
       LEFT JOIN distribusiqurban d ON q.distribusi = d.id 
       WHERE ${whereClause} 
       ORDER BY q.timestamp DESC, q.detail_id DESC 
       LIMIT ? OFFSET ?`,
      [...params, parseInt(limit), parseInt(offset)]
    );

    res.json({
      total,
      data: items,
      page: parseInt(page),
      limit: parseInt(limit)
    });
  } catch (err) {
    console.error('Fetch Qurban List Error:', err);
    res.status(500).json({ message: 'Internal server error' });
  }
});

// POST /api/qurban/bulk-potong (Bulk update status to TERPOTONG)
router.post('/bulk-potong', authMiddleware, async (req, res) => {
  const { detailIds } = req.body;

  if (!detailIds || !Array.isArray(detailIds) || detailIds.length === 0) {
    return res.status(400).json({ message: 'List of detail IDs is required' });
  }

  const connection = await pool.getConnection();
  try {
    await connection.beginTransaction();

    for (const detailId of detailIds) {
      // 1. Check access: must be PJ of the assigned point or Admin
      const [qurbans] = await connection.query(
        `SELECT q.status, q.distribusi, d.user_pj, q.office 
         FROM dataqurban q 
         LEFT JOIN distribusiqurban d ON q.distribusi = d.id 
         WHERE q.detail_id = ?`,
        [detailId]
      );

      if (qurbans.length === 0) {
        throw new Error(`Record ${detailId} not found`);
      }

      const qurban = qurbans[0];

      // Locked check
      if (qurban.status === 'FINISH') {
        throw new Error(`Record ${detailId} is finished and locked.`);
      }

      const isPJ = qurban.user_pj === req.user.login;
      const isAdmin = req.user.priv_admin === 'Y';

      if (!isPJ && !isAdmin) {
        throw new Error(`You are not the PIC/PJ of the distribution area for record ${detailId}.`);
      }

      // 2. Perform status update
      await connection.query(
        "UPDATE dataqurban SET status = 'TERPOTONG', user = ? WHERE detail_id = ?",
        [req.user.login, detailId]
      );
    }

    await connection.commit();
    res.json({ message: `${detailIds.length} records updated to TERPOTONG successfully.` });
  } catch (err) {
    await connection.rollback();
    console.error('Bulk Potong Error:', err);
    res.status(400).json({ message: err.message || 'Internal server error' });
  } finally {
    connection.release();
  }
});

// PUT /api/qurban/:id (Edit qurban data, upload photos, set status)
// We support single edits here
router.put('/:id', authMiddleware, async (req, res) => {
  const detailId = req.params.id;
  const data = req.body;

  const connection = await pool.getConnection();
  try {
    await connection.beginTransaction();

    // 1. Fetch current record
    const [qurbans] = await connection.query(
      `SELECT q.status, q.qty, q.distribusi, d.user_pj, q.office 
       FROM dataqurban q 
       LEFT JOIN distribusiqurban d ON q.distribusi = d.id 
       WHERE q.detail_id = ?`,
      [detailId]
    );

    if (qurbans.length === 0) {
      connection.release();
      return res.status(404).json({ message: 'Qurban record not found' });
    }

    const qurban = qurbans[0];

    // Locked check
    if (qurban.status === 'FINISH') {
      connection.release();
      return res.status(403).json({ message: 'This qurban record is FINISHED and locked.' });
    }

    // 2. Authorization check
    // If it is in OPEN state (no distribution point yet), anyone in the office or admin can assign the distribution point.
    // Once a distribution point is set, ONLY the PJ user (user_pj) of that point or Admin can make edits.
    const hasPoint = qurban.distribusi !== null && qurban.distribusi !== '';
    const isPJ = hasPoint && qurban.user_pj === req.user.login;
    const isAdmin = req.user.priv_admin === 'Y';
    
    // Check if user is in same office (hierarchical check)
    const officeFilter = getOfficeQueryFilter(req.user, 'office');
    const [checkOffice] = await connection.query(
      `SELECT detail_id FROM dataqurban WHERE detail_id = ? AND ${officeFilter.sql}`,
      [detailId, ...officeFilter.params]
    );
    const inOffice = checkOffice.length > 0;

    if (!isAdmin) {
      if (hasPoint && !isPJ) {
        connection.release();
        return res.status(403).json({ message: 'Only the PIC/PJ of the distribution point can edit this record.' });
      }
      if (!hasPoint && !inOffice) {
        connection.release();
        return res.status(403).json({ message: 'You do not have permission to edit records outside your office.' });
      }
    }

    // 3. Quota Management
    // If distribution point is changing or being set:
    const newDistPointId = data.distribusi;
    const oldDistPointId = qurban.distribusi;
    const qty = parseInt(qurban.qty || 1);

    if (newDistPointId !== undefined && newDistPointId !== oldDistPointId) {
      // Restore quota on old point
      if (oldDistPointId) {
        await connection.query(
          'UPDATE distribusiqurban SET tersedia = tersedia + ? WHERE id = ?',
          [qty, oldDistPointId]
        );
      }

      // Deduct quota on new point
      if (newDistPointId) {
        // Fetch new point to check if it's active and has quota
        const [points] = await connection.query(
          "SELECT status, tersedia, quota FROM distribusiqurban WHERE id = ?",
          [newDistPointId]
        );

        if (points.length === 0) {
          throw new Error('Selected distribution point not found.');
        }

        const point = points[0];

        if (point.status !== 'ON') {
          throw new Error('Selected distribution point is inactive.');
        }

        if (point.tersedia < qty) {
          throw new Error(`Insufficient quota at selected distribution point. Available: ${point.tersedia}, Required: ${qty}`);
        }

        await connection.query(
          'UPDATE distribusiqurban SET tersedia = tersedia - ? WHERE id = ?',
          [qty, newDistPointId]
        );
      }
    }

    // 4. Determine new status
    // Rule:
    // - If it was OPEN and distribution point is set -> status goes to TERDISTRIBUSI
    // - User can also set status manually (e.g. TERPOTONG, VERIFIKASI, FINISH)
    let finalStatus = data.status || qurban.status;
    if (qurban.status === 'OPEN' && newDistPointId && (!data.status || data.status === 'OPEN')) {
      finalStatus = 'TERDISTRIBUSI';
    }

    // 5. Update Qurban Fields
    // If distribution point is set, we set pic_lapangan to the user_pj of the point
    let picLapangan = qurban.pic_lapangan;
    if (newDistPointId) {
      const [pjResult] = await connection.query(
        'SELECT user_pj FROM distribusiqurban WHERE id = ?',
        [newDistPointId]
      );
      if (pjResult.length > 0) {
        picLapangan = pjResult[0].user_pj;
      }
    }

    const updates = {
      distribusi: newDistPointId,
      pic_lapangan: picLapangan,
      notes: data.notes,
      keterangan: data.keterangan,
      status: finalStatus,
      user: req.user.login,
      foto1: data.foto1,
      foto2: data.foto2,
      foto3: data.foto3,
      url_foto1: data.url_foto1,
      url_foto2: data.url_foto2,
      url_foto3: data.url_foto3,
      alasan: data.alasan
    };

    const updateFields = [];
    const params = [];
    for (const [key, val] of Object.entries(updates)) {
      if (val !== undefined) {
        updateFields.push(`${key} = ?`);
        params.push(val);
      }
    }

    if (updateFields.length > 0) {
      params.push(detailId);
      await connection.query(
        `UPDATE dataqurban SET ${updateFields.join(', ')} WHERE detail_id = ?`,
        params
      );
    }

    await connection.commit();
    res.json({ message: 'Qurban updated successfully', status: finalStatus });
  } catch (err) {
    await connection.rollback();
    console.error('Update Qurban Error:', err);
    res.status(400).json({ message: err.message || 'Internal server error' });
  } finally {
    connection.release();
  }
});

// POST /api/qurban/:id/photos (Upload photos for Qurban)
// Fields: foto1, foto2, foto3
router.post('/:id/photos', authMiddleware, upload.fields([
  { name: 'foto1', maxCount: 1 },
  { name: 'foto2', maxCount: 1 },
  { name: 'foto3', maxCount: 1 }
]), async (req, res) => {
  const detailId = req.params.id;
  const files = req.files;

  if (!files || Object.keys(files).length === 0) {
    return res.status(400).json({ message: 'No photos uploaded' });
  }

  try {
    // 1. Fetch current qurban
    const [qurbans] = await pool.query('SELECT status, foto1, foto2, foto3 FROM dataqurban WHERE detail_id = ?', [detailId]);
    if (qurbans.length === 0) {
      return res.status(404).json({ message: 'Qurban record not found' });
    }

    const qurban = qurbans[0];
    if (qurban.status === 'FINISH') {
      return res.status(403).json({ message: 'This qurban record is FINISHED and locked.' });
    }

    const updates = {};

    // 2. Upload each photo
    const photoFields = ['foto1', 'foto2', 'foto3'];
    for (const field of photoFields) {
      if (files[field] && files[field][0]) {
        const fileObj = files[field][0];
        const localPath = fileObj.path;
        const targetKey = `qurban_photos/${detailId}_${field}${path.extname(fileObj.originalname)}`;
        
        // Upload to storage (COS or local fallback)
        const publicUrl = await uploadToStorage(localPath, targetKey);
        
        updates[field] = fileObj.filename; // filename stored in database
        updates[`url_${field}`] = publicUrl; // full url
      }
    }

    // Rule: "VERIFIKASI (jika data foto2 sdh di upload)"
    // Let's assume if at least two photos exist or are newly uploaded, we can set the status to VERIFIKASI
    // Let's check current + updated photos:
    const finalFoto1 = updates.foto1 || qurban.foto1;
    const finalFoto2 = updates.foto2 || qurban.foto2;
    const finalFoto3 = updates.foto3 || qurban.foto3;

    // If we have at least foto1 and foto2, let's mark it as VERIFIKASI automatically
    if (finalFoto1 && finalFoto2) {
      updates.status = 'VERIFIKASI';
    }

    const updateFields = [];
    const params = [];
    for (const [key, val] of Object.entries(updates)) {
      updateFields.push(`${key} = ?`);
      params.push(val);
    }

    if (updateFields.length > 0) {
      params.push(detailId);
      await pool.query(
        `UPDATE dataqurban SET ${updateFields.join(', ')} WHERE detail_id = ?`,
        params
      );
    }

    res.json({ 
      message: 'Photos uploaded successfully', 
      urls: {
        url_foto1: updates.url_foto1,
        url_foto2: updates.url_foto2,
        url_foto3: updates.url_foto3
      },
      status: updates.status || qurban.status
    });

  } catch (err) {
    console.error('Qurban Upload Photos Error:', err);
    res.status(500).json({ message: 'Internal server error' });
  }
});

module.exports = router;
